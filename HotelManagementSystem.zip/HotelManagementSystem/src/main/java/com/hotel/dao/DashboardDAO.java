
package com.hotel.dao;

import com.hotel.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.LinkedHashMap;
import java.util.Map;

public class DashboardDAO {

    public Map<String, Integer> getDashboardCounts()
            throws SQLException {

        Map<String, Integer> counts = new LinkedHashMap<>();

        String[] keys = {
            "totalRooms",
            "availableRooms",
            "bookedRooms",
            "totalBookings",
            "registeredCustomers",
            "paidBills",
            "unpaidBills",
            "partialBills"
        };

        // Defaults are zero; failed queries must still raise an error.
        for (String key : keys) {
            counts.put(key, 0);
        }

        try (Connection con = DBConnection.getConnection()) {

            counts.put("totalRooms",
                    getCount(con,
                    "SELECT COUNT(*) FROM HOTEL_ROOMS"));

            counts.put("availableRooms",
                    getCount(con,
                    "SELECT COUNT(*) FROM HOTEL_ROOMS r " +
                    "WHERE r.ROOM_STATUS = 'AVAILABLE' " +
                    "AND NOT EXISTS (" +
                    " SELECT 1 FROM HOTEL_BOOKINGS b " +
                    " WHERE b.ROOM_ID = r.ROOM_ID " +
                    " AND b.BOOKING_STATUS IN " +
                    " ('CONFIRMED', 'CHECKED_IN') " +
                    " AND b.CHECK_IN_DATE < TRUNC(SYSDATE) + 1 " +
                    " AND b.CHECK_OUT_DATE > TRUNC(SYSDATE)" +
                    ")"));

            counts.put("bookedRooms",
                    getCount(con,
                    "SELECT COUNT(DISTINCT ROOM_ID) " +
                    "FROM HOTEL_BOOKINGS " +
                    "WHERE BOOKING_STATUS IN " +
                    "('CONFIRMED', 'CHECKED_IN') " +
                    "AND CHECK_IN_DATE < TRUNC(SYSDATE) + 1 " +
                    "AND CHECK_OUT_DATE > TRUNC(SYSDATE)"));

            counts.put("totalBookings",
                    getCount(con,
                    "SELECT COUNT(*) FROM HOTEL_BOOKINGS " +
                    "WHERE BOOKING_STATUS <> 'CANCELLED'"));

            counts.put("registeredCustomers",
                    getCount(con,
                    "SELECT COUNT(*) FROM HOTEL_CUSTOMERS " +
                    "WHERE ACTIVE = 1"));

            counts.put("paidBills",
                    getCount(con,
                    "SELECT COUNT(*) FROM HOTEL_PAYMENTS " +
                    "WHERE PAYMENT_STATUS = 'PAID'"));

            counts.put("unpaidBills",
                    getCount(con,
                    "SELECT COUNT(*) FROM HOTEL_PAYMENTS " +
                    "WHERE PAYMENT_STATUS = 'UNPAID'"));

            counts.put("partialBills",
                    getCount(con,
                    "SELECT COUNT(*) FROM HOTEL_PAYMENTS " +
                    "WHERE PAYMENT_STATUS = 'PARTIAL'"));
        }

        return counts;
    }

    private int getCount(Connection con, String sql)
            throws SQLException {

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }

            return 0;
        }
    }
}
