
package com.hotel.servlet;

import com.hotel.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns={"/admin-billing", "/billing"})
public class AdminBillingServlet extends HttpServlet {

    private boolean isAdmin(HttpSession s) {
        return s != null && (s.getAttribute("adminId") != null
                || "ADMIN".equals(s.getAttribute("role")));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        if (!isAdmin(req.getSession(false))) {
            resp.sendRedirect(req.getContextPath() + "/admin-login.jsp");
            return;
        }

        List<Map<String,Object>> payments = new ArrayList<>();
        String sql = "SELECT p.PAYMENT_ID, p.BOOKING_ID, c.FULL_NAME, " +
                "r.ROOM_NUMBER, p.AMOUNT_DUE, p.AMOUNT_PAID, " +
                "p.PAYMENT_STATUS, p.PAYMENT_METHOD, p.PAYMENT_DATE " +
                "FROM HOTEL_PAYMENTS p " +
                "JOIN HOTEL_BOOKINGS b ON b.BOOKING_ID=p.BOOKING_ID " +
                "JOIN HOTEL_CUSTOMERS c ON c.CUSTOMER_ID=b.CUSTOMER_ID " +
                "JOIN HOTEL_ROOMS r ON r.ROOM_ID=b.ROOM_ID " +
                "ORDER BY p.PAYMENT_ID DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String,Object> p = new HashMap<>();
                p.put("PAYMENT_ID", rs.getObject("PAYMENT_ID"));
                p.put("BOOKING_ID", rs.getObject("BOOKING_ID"));
                p.put("FULL_NAME", rs.getObject("FULL_NAME"));
                p.put("ROOM_NUMBER", rs.getObject("ROOM_NUMBER"));
                p.put("AMOUNT_DUE", rs.getObject("AMOUNT_DUE"));
                p.put("AMOUNT_PAID", rs.getObject("AMOUNT_PAID"));
                p.put("PAYMENT_STATUS", rs.getObject("PAYMENT_STATUS"));
                p.put("PAYMENT_METHOD", rs.getObject("PAYMENT_METHOD"));
                p.put("PAYMENT_DATE", rs.getObject("PAYMENT_DATE"));
                payments.add(p);
            }
        } catch (SQLException e) {
            throw new ServletException("Could not load billing records.", e);
        }

        req.setAttribute("payments", payments);
        req.getRequestDispatcher("/admin-billing.jsp").forward(req, resp);
    }
}
