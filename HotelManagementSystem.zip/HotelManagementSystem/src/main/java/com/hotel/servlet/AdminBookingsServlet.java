
package com.hotel.servlet;

import com.hotel.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns={"/admin-bookings", "/bookings"})
public class AdminBookingsServlet extends HttpServlet {

    private boolean isAdmin(HttpSession s) {
        return s != null && (s.getAttribute("adminId") != null
                || "ADMIN".equals(s.getAttribute("role")));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        if (!isAdmin(req.getSession(false))) {
            resp.sendRedirect(req.getContextPath() + "/admin-login.jsp");
            return;
        }

        List<Map<String,Object>> bookings = new ArrayList<>();
        String sql = "SELECT b.BOOKING_ID, c.FULL_NAME, c.PHONE, " +
                "r.ROOM_NUMBER, r.ROOM_TYPE, b.CHECK_IN_DATE, " +
                "b.CHECK_OUT_DATE, b.BOOKING_STATUS, b.BOOKING_DATE, " +
                "b.TOTAL_AMOUNT FROM HOTEL_BOOKINGS b " +
                "JOIN HOTEL_CUSTOMERS c ON c.CUSTOMER_ID=b.CUSTOMER_ID " +
                "JOIN HOTEL_ROOMS r ON r.ROOM_ID=b.ROOM_ID " +
                "ORDER BY b.BOOKING_ID DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String,Object> b = new HashMap<>();
                b.put("BOOKING_ID", rs.getObject("BOOKING_ID"));
                b.put("FULL_NAME", rs.getObject("FULL_NAME"));
                b.put("PHONE", rs.getObject("PHONE"));
                b.put("ROOM_NUMBER", rs.getObject("ROOM_NUMBER"));
                b.put("ROOM_TYPE", rs.getObject("ROOM_TYPE"));
                b.put("CHECK_IN_DATE", rs.getObject("CHECK_IN_DATE"));
                b.put("CHECK_OUT_DATE", rs.getObject("CHECK_OUT_DATE"));
                b.put("BOOKING_STATUS", rs.getObject("BOOKING_STATUS"));
                b.put("BOOKING_DATE", rs.getObject("BOOKING_DATE"));
                b.put("TOTAL_AMOUNT", rs.getObject("TOTAL_AMOUNT"));
                bookings.add(b);
            }
        } catch (SQLException e) {
            throw new ServletException("Could not load bookings.", e);
        }

        req.setAttribute("bookings", bookings);
        req.getRequestDispatcher("/admin-bookings.jsp").forward(req, resp);
    }
}
