
package com.hotel.servlet;

import com.hotel.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns={"/admin-customers", "/customers"})
public class AdminCustomersServlet extends HttpServlet {

    private boolean isAdmin(HttpSession s) {
        return s != null && (s.getAttribute("adminId") != null
                || "ADMIN".equals(s.getAttribute("role")));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        if (!isAdmin(req.getSession(false))) {
            resp.sendRedirect(req.getContextPath() + "/admin-login.jsp");
            return;
        }

        List<Map<String,Object>> customers = new ArrayList<>();
        String sql = "SELECT CUSTOMER_ID, FULL_NAME, USERNAME, EMAIL, " +
                "PHONE, CREATED_AT, ACTIVE FROM HOTEL_CUSTOMERS " +
                "ORDER BY CUSTOMER_ID DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String,Object> c = new HashMap<>();
                c.put("CUSTOMER_ID", rs.getObject("CUSTOMER_ID"));
                c.put("FULL_NAME", rs.getObject("FULL_NAME"));
                c.put("USERNAME", rs.getObject("USERNAME"));
                c.put("EMAIL", rs.getObject("EMAIL"));
                c.put("PHONE", rs.getObject("PHONE"));
                c.put("CREATED_AT", rs.getObject("CREATED_AT"));
                c.put("ACTIVE", rs.getObject("ACTIVE"));
                customers.add(c);
            }
        } catch (SQLException e) {
            throw new ServletException("Could not load customers.", e);
        }

        req.setAttribute("customers", customers);
        req.getRequestDispatcher("/admin-customers.jsp").forward(req, resp);
    }
}
