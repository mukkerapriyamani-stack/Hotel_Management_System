
package com.hotel.servlet;

import com.hotel.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns={"/admin-rooms", "/rooms"})
public class AdminRoomsServlet extends HttpServlet {

    private boolean isAdmin(HttpSession s) {
        return s != null && (s.getAttribute("adminId") != null
                || "ADMIN".equals(s.getAttribute("role")));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        if (!isAdmin(req.getSession(false))) {
            resp.sendRedirect(req.getContextPath() + "/admin-login.jsp");
            return;
        }

        List<Map<String,Object>> rooms = new ArrayList<>();

        String sql = "SELECT ROOM_ID, ROOM_NUMBER, ROOM_TYPE, DESCRIPTION, " +
                "PRICE_PER_NIGHT, ROOM_STATUS, IMAGE_URL " +
                "FROM HOTEL_ROOMS ORDER BY ROOM_ID";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String,Object> r = new HashMap<>();
                r.put("ROOM_ID", rs.getObject("ROOM_ID"));
                r.put("ROOM_NUMBER", rs.getObject("ROOM_NUMBER"));
                r.put("ROOM_TYPE", rs.getObject("ROOM_TYPE"));
                r.put("DESCRIPTION", rs.getObject("DESCRIPTION"));
                r.put("PRICE_PER_NIGHT", rs.getObject("PRICE_PER_NIGHT"));
                r.put("ROOM_STATUS", rs.getObject("ROOM_STATUS"));
                r.put("IMAGE_URL", rs.getObject("IMAGE_URL"));
                rooms.add(r);
            }
        } catch (SQLException e) {
            throw new ServletException("Could not load rooms.", e);
        }

        req.setAttribute("rooms", rooms);
        req.getRequestDispatcher("/admin-rooms.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        if (!isAdmin(req.getSession(false))) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        String action = req.getParameter("action");
        String message;

        try (Connection con = DBConnection.getConnection()) {
            if ("add".equals(action) || "update".equals(action)) {
                String number = req.getParameter("roomNumber");
                String type = req.getParameter("roomType");
                String description = req.getParameter("description");
                String priceText = req.getParameter("price");
                String status = req.getParameter("status");
                String image = req.getParameter("imageUrl");

                if (number == null || number.trim().isEmpty()
                        || type == null || type.trim().isEmpty()
                        || priceText == null) {
                    throw new IllegalArgumentException(
                            "Room number, room type, and price are required.");
                }

                double price = Double.parseDouble(priceText);
                if (!Double.isFinite(price) || price <= 0) {
                    throw new IllegalArgumentException(
                            "Price must be greater than zero.");
                }

                if (!"AVAILABLE".equals(status)
                        && !"UNAVAILABLE".equals(status)) {
                    throw new IllegalArgumentException("Invalid room status.");
                }

                if ("add".equals(action)) {
                    String sql = "INSERT INTO HOTEL_ROOMS " +
                            "(ROOM_ID, ROOM_NUMBER, ROOM_TYPE, DESCRIPTION, " +
                            "PRICE_PER_NIGHT, ROOM_STATUS, IMAGE_URL) " +
                            "SELECT NVL(MAX(ROOM_ID),0)+1, ?, ?, ?, ?, ?, ? " +
                            "FROM HOTEL_ROOMS";

                    try (PreparedStatement ps = con.prepareStatement(sql)) {
                        ps.setString(1, number.trim());
                        ps.setString(2, type.trim());
                        ps.setString(3, description);
                        ps.setDouble(4, price);
                        ps.setString(5, status);
                        ps.setString(6, image);
                        ps.executeUpdate();
                    }
                    message = "Room added successfully.";
                } else {
                    int id = Integer.parseInt(req.getParameter("roomId"));
                    String sql = "UPDATE HOTEL_ROOMS SET ROOM_NUMBER=?, " +
                            "ROOM_TYPE=?, DESCRIPTION=?, PRICE_PER_NIGHT=?, " +
                            "ROOM_STATUS=?, IMAGE_URL=? WHERE ROOM_ID=?";

                    try (PreparedStatement ps = con.prepareStatement(sql)) {
                        ps.setString(1, number.trim());
                        ps.setString(2, type.trim());
                        ps.setString(3, description);
                        ps.setDouble(4, price);
                        ps.setString(5, status);
                        ps.setString(6, image);
                        ps.setInt(7, id);
                        if (ps.executeUpdate() == 0) {
                            throw new IllegalArgumentException("Room not found.");
                        }
                    }
                    message = "Room updated successfully.";
                }
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("roomId"));
                try (PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM HOTEL_ROOMS WHERE ROOM_ID=?")) {
                    ps.setInt(1, id);
                    if (ps.executeUpdate() == 0) {
                        throw new IllegalArgumentException("Room not found.");
                    }
                }
                message = "Room deleted successfully.";
            } else {
                throw new IllegalArgumentException("Unknown action.");
            }
        } catch (IllegalArgumentException e) {
            message = e.getMessage();
        } catch (SQLException e) {
            message = "Database operation failed. The room may have existing " +
                    "bookings, or its room number may already exist.";
        }

        resp.sendRedirect(req.getContextPath() + "/admin-rooms?message=" +
                URLEncoder.encode(message, StandardCharsets.UTF_8.name()));
    }
}
