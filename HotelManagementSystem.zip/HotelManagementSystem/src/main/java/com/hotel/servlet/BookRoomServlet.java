
package com.hotel.servlet;

import com.hotel.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@WebServlet("/book-room")
public class BookRoomServlet extends HttpServlet {

    private Integer getCustomerId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);

        if (session == null ||
            !"CUSTOMER".equals(session.getAttribute("role")) ||
            session.getAttribute("customerId") == null) {
            return null;
        }

        Object id = session.getAttribute("customerId");

        if (id instanceof Number) {
            return ((Number) id).intValue();
        }

        try {
            return Integer.parseInt(id.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        Integer customerId = getCustomerId(request);

        if (customerId == null) {
            response.sendRedirect(
                request.getContextPath() + "/customer-login.jsp");
            return;
        }

        try {
            int roomId = Integer.parseInt(request.getParameter("roomId"));

            try (Connection con = DBConnection.getConnection()) {

                String roomSql =
                    "SELECT ROOM_ID, ROOM_NUMBER, ROOM_TYPE, DESCRIPTION, " +
                    "PRICE_PER_NIGHT, ROOM_STATUS, IMAGE_URL " +
                    "FROM HOTEL_ROOMS WHERE ROOM_ID = ?";

                try (PreparedStatement ps = con.prepareStatement(roomSql)) {
                    ps.setInt(1, roomId);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            response.sendError(404, "Room not found");
                            return;
                        }

                        request.setAttribute("roomId", rs.getInt("ROOM_ID"));
                        request.setAttribute("roomNumber", rs.getString("ROOM_NUMBER"));
                        request.setAttribute("roomType", rs.getString("ROOM_TYPE"));
                        request.setAttribute("description", rs.getString("DESCRIPTION"));
                        request.setAttribute("price", rs.getBigDecimal("PRICE_PER_NIGHT"));
                        request.setAttribute("roomStatus", rs.getString("ROOM_STATUS"));
                        request.setAttribute("imageUrl", rs.getString("IMAGE_URL"));
                    }
                }

                String customerSql =
                    "SELECT FULL_NAME, EMAIL, PHONE " +
                    "FROM HOTEL_CUSTOMERS WHERE CUSTOMER_ID = ?";

                try (PreparedStatement ps = con.prepareStatement(customerSql)) {
                    ps.setInt(1, customerId);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            response.sendRedirect(
                                request.getContextPath() + "/customer-login.jsp");
                            return;
                        }

                        request.setAttribute("fullName", rs.getString("FULL_NAME"));
                        request.setAttribute("email", rs.getString("EMAIL"));
                        request.setAttribute("phone", rs.getString("PHONE"));
                    }
                }
            }

            request.getRequestDispatcher("/book-room.jsp")
                   .forward(request, response);

        } catch (NumberFormatException e) {
            response.sendError(400, "Invalid room ID");
        } catch (SQLException e) {
            throw new ServletException("Could not load booking details", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        Integer customerId = getCustomerId(request);

        if (customerId == null) {
            response.sendRedirect(
                request.getContextPath() + "/customer-login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");

        try {
            int roomId = Integer.parseInt(request.getParameter("roomId"));
            String fullName = request.getParameter("fullName").trim();
            String email = request.getParameter("email").trim();
            String phone = request.getParameter("phone").trim();

            LocalDate checkIn =
                LocalDate.parse(request.getParameter("checkIn"));
            LocalDate checkOut =
                LocalDate.parse(request.getParameter("checkOut"));

            int guests = Integer.parseInt(request.getParameter("guests"));

            if (fullName.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                throw new IllegalArgumentException("Please fill in all contact details.");
            }

            if (checkIn.isBefore(LocalDate.now())) {
                throw new IllegalArgumentException("Check-in cannot be in the past.");
            }

            if (!checkOut.isAfter(checkIn)) {
                throw new IllegalArgumentException(
                    "Check-out must be after check-in.");
            }

            if (guests < 1 || guests > 10) {
                throw new IllegalArgumentException(
                    "Number of guests must be between 1 and 10.");
            }

            long nights = ChronoUnit.DAYS.between(checkIn, checkOut);

            try (Connection con = DBConnection.getConnection()) {
                con.setAutoCommit(false);

                try {
                    BigDecimal price;
                    String roomStatus;

                    String roomSql =
                        "SELECT PRICE_PER_NIGHT, ROOM_STATUS " +
                        "FROM HOTEL_ROOMS WHERE ROOM_ID = ? FOR UPDATE";

                    try (PreparedStatement ps = con.prepareStatement(roomSql)) {
                        ps.setInt(1, roomId);

                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) {
                                throw new IllegalArgumentException(
                                    "This room does not exist.");
                            }

                            price = rs.getBigDecimal("PRICE_PER_NIGHT");
                            roomStatus = rs.getString("ROOM_STATUS");
                        }
                    }

                    if (roomStatus == null ||
                        !"AVAILABLE".equalsIgnoreCase(roomStatus)) {
                        throw new IllegalArgumentException(
                            "This room is not currently available.");
                    }

                    String availabilitySql =
                        "SELECT COUNT(*) FROM HOTEL_BOOKINGS " +
                        "WHERE ROOM_ID = ? " +
                        "AND UPPER(BOOKING_STATUS) <> 'CANCELLED' " +
                        "AND CHECK_IN_DATE < ? AND CHECK_OUT_DATE > ?";

                    try (PreparedStatement ps =
                             con.prepareStatement(availabilitySql)) {
                        ps.setInt(1, roomId);
                        ps.setDate(2, Date.valueOf(checkOut));
                        ps.setDate(3, Date.valueOf(checkIn));

                        try (ResultSet rs = ps.executeQuery()) {
                            rs.next();

                            if (rs.getInt(1) > 0) {
                                throw new IllegalArgumentException(
                                    "This room is already booked for those dates.");
                            }
                        }
                    }

                    BigDecimal total = price.multiply(
                        BigDecimal.valueOf(nights));

                    String customerSql =
                        "UPDATE HOTEL_CUSTOMERS " +
                        "SET FULL_NAME = ?, EMAIL = ?, PHONE = ? " +
                        "WHERE CUSTOMER_ID = ?";

                    try (PreparedStatement ps =
                             con.prepareStatement(customerSql)) {
                        ps.setString(1, fullName);
                        ps.setString(2, email);
                        ps.setString(3, phone);
                        ps.setInt(4, customerId);
                        ps.executeUpdate();
                    }

                    String insertSql =
                        "INSERT INTO HOTEL_BOOKINGS " +
                        "(BOOKING_ID, CUSTOMER_ID, ROOM_ID, " +
                        "CHECK_IN_DATE, CHECK_OUT_DATE, BOOKING_STATUS, " +
                        "BOOKING_DATE, TOTAL_AMOUNT, NUMBER_OF_GUESTS) " +
                        "VALUES (HOTEL_BOOKINGS_SEQ.NEXTVAL, ?, ?, ?, ?, " +
                        "'CONFIRMED', SYSDATE, ?, ?)";

                    try (PreparedStatement ps =
                             con.prepareStatement(insertSql)) {
                        ps.setInt(1, customerId);
                        ps.setInt(2, roomId);
                        ps.setDate(3, Date.valueOf(checkIn));
                        ps.setDate(4, Date.valueOf(checkOut));
                        ps.setBigDecimal(5, total);
                        ps.setInt(6, guests);
                        ps.executeUpdate();
                    }

                    con.commit();

                    response.sendRedirect(
                        request.getContextPath() +
                        "/customer-bookings?bookingSuccess=true");
                    return;

                } catch (SQLException | RuntimeException e) {
                    try {
                        con.rollback();
                    } catch (SQLException ignored) {
                    }
                    throw e;
                }finally {
                    try {
                        con.setAutoCommit(true);
                    } catch (SQLException ignored) {
                    }
                }
            }

        } catch (IllegalArgumentException e) {
            request.setAttribute("errorMessage", e.getMessage());
            doGet(request, response);
        } catch (SQLException e) {
            throw new ServletException("Could not save the booking", e);
        }
    }
}
