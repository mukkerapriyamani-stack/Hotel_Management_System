
package com.hotel.servlet;

import com.hotel.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/customer-bookings")
public class CustomerBookingsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
            session.getAttribute("customerId") == null ||
            !"CUSTOMER".equals(session.getAttribute("role"))) {

            response.sendRedirect(
                request.getContextPath() + "/customer-login.jsp");
            return;
        }

        int customerId =
            ((Number) session.getAttribute("customerId")).intValue();

        List<Map<String, Object>> bookings =
            new ArrayList<Map<String, Object>>();

        String sql =
            "SELECT b.BOOKING_ID, b.ROOM_ID, r.ROOM_NUMBER, " +
            "r.ROOM_TYPE, b.CHECK_IN_DATE, b.CHECK_OUT_DATE, " +
            "b.NUMBER_OF_GUESTS, b.BOOKING_STATUS, " +
            "b.BOOKING_DATE, b.TOTAL_AMOUNT " +
            "FROM HOTEL_BOOKINGS b " +
            "JOIN HOTEL_ROOMS r ON b.ROOM_ID = r.ROOM_ID " +
            "WHERE b.CUSTOMER_ID = ? " +
            "ORDER BY b.BOOKING_ID DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, customerId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> booking =
                        new HashMap<String, Object>();

                    booking.put("BOOKING_ID", rs.getObject("BOOKING_ID"));
                    booking.put("ROOM_ID", rs.getObject("ROOM_ID"));
                    booking.put("ROOM_NUMBER", rs.getObject("ROOM_NUMBER"));
                    booking.put("ROOM_TYPE", rs.getObject("ROOM_TYPE"));
                    booking.put("CHECK_IN_DATE", rs.getObject("CHECK_IN_DATE"));
                    booking.put("CHECK_OUT_DATE", rs.getObject("CHECK_OUT_DATE"));
                    booking.put("NUMBER_OF_GUESTS",
                                rs.getObject("NUMBER_OF_GUESTS"));
                    booking.put("BOOKING_STATUS",
                                rs.getObject("BOOKING_STATUS"));
                    booking.put("BOOKING_DATE", rs.getObject("BOOKING_DATE"));
                    booking.put("TOTAL_AMOUNT", rs.getObject("TOTAL_AMOUNT"));

                    bookings.add(booking);
                }
            }

        } catch (SQLException e) {
            throw new ServletException(
                "Unable to retrieve your bookings from Oracle.", e);
        }

        request.setAttribute("bookings", bookings);

        request.getRequestDispatcher("/customer-bookings.jsp")
               .forward(request, response);
    }
}
