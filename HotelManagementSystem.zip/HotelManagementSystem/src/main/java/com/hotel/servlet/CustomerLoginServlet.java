
package com.hotel.servlet;

import com.hotel.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

@WebServlet("/customer-login")
public class CustomerLoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || username.trim().isEmpty()
                || password == null || password.isEmpty()) {
            request.setAttribute("error",
                "Please enter your username and password.");
            request.getRequestDispatcher("/customer-login.jsp")
                   .forward(request, response);
            return;
        }

        String sql =
            "SELECT CUSTOMER_ID, FULL_NAME, PASSWORD_SALT, PASSWORD_HASH " +
            "FROM HOTEL_CUSTOMERS " +
            "WHERE UPPER(USERNAME) = UPPER(?) AND ACTIVE = 1";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username.trim());

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {
                    request.setAttribute("error",
                        "Account not found. Please create an account.");

                    request.getRequestDispatcher("/customer-login.jsp")
                           .forward(request, response);
                    return;
                }

                int customerId = rs.getInt("CUSTOMER_ID");
                String fullName = rs.getString("FULL_NAME");
                String salt = rs.getString("PASSWORD_SALT");
                String storedHash = rs.getString("PASSWORD_HASH");

                if (salt == null || storedHash == null) {
                    request.setAttribute("error",
                        "This account has incomplete login data. Please contact the administrator.");

                    request.getRequestDispatcher("/customer-login.jsp")
                           .forward(request, response);
                    return;
                }

                byte[] saltBytes = Base64.getDecoder().decode(salt);
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                digest.update(saltBytes);

                byte[] hashBytes =
                    digest.digest(password.getBytes(StandardCharsets.UTF_8));

                String enteredHash =
                    Base64.getEncoder().encodeToString(hashBytes);

                boolean matches = MessageDigest.isEqual(
                    enteredHash.getBytes(StandardCharsets.UTF_8),
                    storedHash.getBytes(StandardCharsets.UTF_8));

                if (!matches) {
                    request.setAttribute("error",
                        "Incorrect password. Please try again.");

                    request.getRequestDispatcher("/customer-login.jsp")
                           .forward(request, response);
                    return;
                }

                // Create the authenticated customer session.
                HttpSession session = request.getSession(true);
                request.changeSessionId();

                session.setAttribute("customerId", customerId);
                session.setAttribute("customerName", fullName);
                session.setAttribute("role", "CUSTOMER");

                response.sendRedirect(
                    request.getContextPath() + "/customer-portal.jsp");
            }

        } catch (SQLException e) {
            getServletContext().log("Customer login database error", e);

            request.setAttribute("error",
                "A database error occurred. Please try again later.");

            request.getRequestDispatcher("/customer-login.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            getServletContext().log("Customer login error", e);

            request.setAttribute("error",
                "Unable to complete login. Please try again.");

            request.getRequestDispatcher("/customer-login.jsp")
                   .forward(request, response);
        }
    }
}
