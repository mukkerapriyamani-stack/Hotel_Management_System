
package com.hotel.servlet;

import com.hotel.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

@WebServlet("/customer-register")
public class CustomerRegisterServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String fullName = request.getParameter("fullName");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        if (fullName == null || username == null || email == null
                || phone == null || password == null
                || confirmPassword == null
                || fullName.trim().isEmpty()
                || username.trim().isEmpty()
                || email.trim().isEmpty()
                || phone.trim().isEmpty()) {
            showError(request, response, "Please fill in every field.");
            return;
        }

        fullName = fullName.trim();
        username = username.trim();
        email = email.trim();
        phone = phone.trim();

        if (fullName.length() > 100 || username.length() > 50
                || email.length() > 150 || phone.length() > 20) {
            showError(request, response,
                    "One or more fields are too long.");
            return;
        }

        if (password.length() < 8) {
            showError(request, response,
                    "Password must be at least 8 characters.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showError(request, response, "Passwords do not match.");
            return;
        }

        String checkSql =
            "SELECT CUSTOMER_ID FROM HOTEL_CUSTOMERS " +
            "WHERE UPPER(USERNAME) = UPPER(?)";

        String insertSql =
            "INSERT INTO HOTEL_CUSTOMERS " +
            "(CUSTOMER_ID, FULL_NAME, USERNAME, PASSWORD_SALT, " +
            "PASSWORD_HASH, EMAIL, PHONE, CREATED_AT, ACTIVE) " +
            "VALUES (HOTEL_CUSTOMERS_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, SYSDATE, 1)";

        try (Connection con = DBConnection.getConnection()) {

            // Check for an existing username.
            try (PreparedStatement check = con.prepareStatement(checkSql)) {
                check.setString(1, username);

                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next()) {
                        showError(request, response,
                            "This username is already registered. Please log in or choose another username.");
                        return;
                    }
                }
            }

            // Create a unique random salt for this password.
            byte[] saltBytes = new byte[16];
            new SecureRandom().nextBytes(saltBytes);
            String salt = Base64.getEncoder().encodeToString(saltBytes);

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(saltBytes);
            byte[] hashBytes =
                digest.digest(password.getBytes(StandardCharsets.UTF_8));

            String passwordHash =
                Base64.getEncoder().encodeToString(hashBytes);

            try (PreparedStatement insert = con.prepareStatement(insertSql)) {
                insert.setString(1, fullName);
                insert.setString(2, username);
                insert.setString(3, salt);
                insert.setString(4, passwordHash);
                insert.setString(5, email);
                insert.setString(6, phone);

                int rows = insert.executeUpdate();

                if (rows == 1) {
                    // Redirect to login after the database insert succeeds.
                    response.sendRedirect(request.getContextPath()
                        + "/customer-login.jsp?registered=true");
                } else {
                    showError(request, response,
                        "Account was not created. Please try again.");
                }
            }

        } catch (SQLException e) {
            getServletContext().log("Customer registration SQL error", e);

            if (e.getErrorCode() == 1) {
                showError(request, response,
                    "This username or another unique field is already registered.");
            } else {
                showError(request, response,
                    "Could not save the account. Check the database table, sequence, and server log.");
            }

        } catch (Exception e) {
            getServletContext().log("Customer registration error", e);
            showError(request, response,
                "Could not create the account. Please try again.");
        }
    }

    private void showError(HttpServletRequest request,
                           HttpServletResponse response,
                           String message)
            throws ServletException, IOException {
        request.setAttribute("error", message);
        request.getRequestDispatcher("/customer-register.jsp")
               .forward(request, response);
    }
}
