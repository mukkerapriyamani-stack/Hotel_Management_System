
package com.hotel.servlet;

import com.hotel.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/customer-rooms")
public class CustomerRoomsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
            session.getAttribute("customerId") == null ||
            !"CUSTOMER".equals(session.getAttribute("role"))) {

            response.sendRedirect(
                request.getContextPath() + "/customer-login.jsp");
            return;
        }

        List<Map<String, Object>> rooms =
            new ArrayList<Map<String, Object>>();

        String sql =
            "SELECT ROOM_ID, ROOM_NUMBER, ROOM_TYPE, DESCRIPTION, " +
            "PRICE_PER_NIGHT, ROOM_STATUS, IMAGE_URL " +
            "FROM HOTEL_ROOMS ORDER BY PRICE_PER_NIGHT";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> room =
                    new HashMap<String, Object>();

                // These names must match customer-rooms.jsp
                room.put("ROOM_ID", rs.getObject("ROOM_ID"));
                room.put("ROOM_NUMBER", rs.getObject("ROOM_NUMBER"));
                room.put("ROOM_TYPE", rs.getObject("ROOM_TYPE"));
                room.put("DESCRIPTION", rs.getObject("DESCRIPTION"));
                room.put("PRICE_PER_NIGHT",
                         rs.getObject("PRICE_PER_NIGHT"));
                room.put("ROOM_STATUS", rs.getObject("ROOM_STATUS"));
                room.put("IMAGE_URL", rs.getObject("IMAGE_URL"));

                rooms.add(room);
            }

        } catch (SQLException e) {
            throw new ServletException(
                "Error loading hotel rooms from Oracle database.", e);
        }

        request.setAttribute("rooms", rooms);

        request.getRequestDispatcher("/customer-rooms.jsp")
               .forward(request, response);
    }
}
