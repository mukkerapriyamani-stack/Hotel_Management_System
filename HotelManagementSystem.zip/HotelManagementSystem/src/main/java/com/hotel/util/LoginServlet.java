
package com.hotel.util;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // TEMPORARY DEMO LOGIN ONLY
        // Replace with Oracle authentication later.
        if ("admin".equals(username) &&
            "admin123".equals(password)) {

            HttpSession session = request.getSession(true);
            request.changeSessionId();

            session.setAttribute("adminUsername", username);
            session.setAttribute("role", "ADMIN");

            response.sendRedirect(
                request.getContextPath() + "/dashboard.jsp");

        } else {
            response.sendRedirect(
                request.getContextPath() + "/login.jsp?error=1");
        }
    }
}
