
package com.hotel.util;

import java.sql.Connection;

public class TestDBConnection {

    public static void main(String[] args) {

        try (Connection con = DBConnection.getConnection()) {

            if (con != null && !con.isClosed()) {
                System.out.println("SUCCESS: Oracle connected!");
            }

        } catch (Exception e) {
            System.out.println("FAILED: Oracle connection error.");
            System.out.println("Reason: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
