
<%@ page import="java.util.List,java.util.Map" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
String esc(Object v){
 if(v==null)return "";
 return v.toString().replace("&","&amp;").replace("<","&lt;")
 .replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");
}
double amount(Object v){
 return v instanceof Number ? ((Number)v).doubleValue() : 0.0;
}
%>
<%
if(session.getAttribute("adminId")==null&&!"ADMIN".equals(session.getAttribute("role"))){
 response.sendRedirect(request.getContextPath()+"/admin-login.jsp");return;
}
List<Map<String,Object>> payments=(List<Map<String,Object>>)request.getAttribute("payments");
String ctx=request.getContextPath();
%>
<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manage Billing</title>
<style>
body{margin:0;background:#f0f4f8;color:#183153;font-family:Arial}
header{background:#102a56;color:white;padding:20px 4%;display:flex;justify-content:space-between;flex-wrap:wrap}
header a{color:white}main{width:96%;margin:25px auto}.panel{background:white;padding:22px;border-radius:12px}
.wrap{overflow-x:auto}table{width:100%;border-collapse:collapse}
td,th{text-align:left;padding:11px;border-bottom:1px solid #ddd;white-space:nowrap}
th{background:#eaf0f6}.note{color:#64748b}
</style></head><body>
<header><h2>Billing Management</h2><a href="<%=ctx%>/admin-dashboard.jsp">Dashboard</a></header>
<main><section class="panel"><h2>Payment Records</h2>
<p class="note">Amounts shown are database records. This page does not process payments.</p>
<div class="wrap"><table>
<tr><th>Payment ID</th><th>Booking ID</th><th>Customer</th><th>Room No.</th>
<th>Amount Due</th><th>Amount Paid</th><th>Balance</th><th>Status</th>
<th>Method</th><th>Payment Date</th></tr>
<%if(payments!=null&&!payments.isEmpty()){for(Map<String,Object> p:payments){
 double due=amount(p.get("AMOUNT_DUE"));
 double paid=amount(p.get("AMOUNT_PAID"));
 double balance=Math.max(0,due-paid);
%>
<tr><td><%=esc(p.get("PAYMENT_ID"))%></td>
<td><%=esc(p.get("BOOKING_ID"))%></td><td><%=esc(p.get("FULL_NAME"))%></td>
<td><%=esc(p.get("ROOM_NUMBER"))%></td>
<td>₹<%=String.format(java.util.Locale.US,"%.2f",due)%></td>
<td>₹<%=String.format(java.util.Locale.US,"%.2f",paid)%></td>
<td>₹<%=String.format(java.util.Locale.US,"%.2f",balance)%></td>
<td><%=esc(p.get("PAYMENT_STATUS"))%></td><td><%=esc(p.get("PAYMENT_METHOD"))%></td>
<td><%=esc(p.get("PAYMENT_DATE"))%></td></tr>
<%}}else{%><tr><td colspan="10">No payment records found yet.</td></tr><%}%>
</table></div></section></main></body></html>
