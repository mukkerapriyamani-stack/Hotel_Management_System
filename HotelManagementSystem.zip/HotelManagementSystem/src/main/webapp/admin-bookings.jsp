
<%@ page import="java.util.List,java.util.Map" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
String esc(Object v){
 if(v==null)return "";
 return v.toString().replace("&","&amp;").replace("<","&lt;")
 .replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");
}
%>
<%
if(session.getAttribute("adminId")==null&&!"ADMIN".equals(session.getAttribute("role"))){
 response.sendRedirect(request.getContextPath()+"/admin-login.jsp");return;
}
List<Map<String,Object>> bookings=(List<Map<String,Object>>)request.getAttribute("bookings");
String ctx=request.getContextPath();
%>
<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manage Bookings</title>
<style>
body{margin:0;background:#f0f4f8;color:#183153;font-family:Arial}
header{background:#102a56;color:white;padding:20px 4%;display:flex;justify-content:space-between;flex-wrap:wrap}
header a{color:white}main{width:96%;margin:25px auto}.panel{background:white;padding:22px;border-radius:12px}
.wrap{overflow-x:auto}table{width:100%;border-collapse:collapse}
td,th{text-align:left;padding:11px;border-bottom:1px solid #ddd;white-space:nowrap}
th{background:#eaf0f6}
</style></head><body>
<header><h2>Booking Management</h2><a href="<%=ctx%>/admin-dashboard.jsp">Dashboard</a></header>
<main><section class="panel"><h2>All Reservations</h2><div class="wrap"><table>
<tr><th>Booking ID</th><th>Customer</th><th>Phone</th><th>Room No.</th>
<th>Room Type</th><th>Check-in</th><th>Check-out</th><th>Status</th>
<th>Booking Date</th><th>Total</th></tr>
<%if(bookings!=null&&!bookings.isEmpty()){for(Map<String,Object> b:bookings){%>
<tr><td><%=esc(b.get("BOOKING_ID"))%></td><td><%=esc(b.get("FULL_NAME"))%></td>
<td><%=esc(b.get("PHONE"))%></td><td><%=esc(b.get("ROOM_NUMBER"))%></td>
<td><%=esc(b.get("ROOM_TYPE"))%></td><td><%=esc(b.get("CHECK_IN_DATE"))%></td>
<td><%=esc(b.get("CHECK_OUT_DATE"))%></td><td><%=esc(b.get("BOOKING_STATUS"))%></td>
<td><%=esc(b.get("BOOKING_DATE"))%></td><td>₹<%=esc(b.get("TOTAL_AMOUNT"))%></td></tr>
<%}}else{%><tr><td colspan="10">No bookings found yet.</td></tr><%}%>
</table></div></section></main></body></html>
