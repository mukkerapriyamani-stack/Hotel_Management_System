
<%@ page import="java.util.List,java.util.Map" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
String esc(Object v){
 if(v==null)return "";
 return v.toString().replace("&","&amp;").replace("<","&lt;")
 .replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");
}
%>
<%
if(session.getAttribute("adminId")==null&&!"ADMIN".equals(session.getAttribute("role"))){
 response.sendRedirect(request.getContextPath()+"/admin-login.jsp");return;
}
List<Map<String,Object>> customers=(List<Map<String,Object>>)request.getAttribute("customers");
String ctx=request.getContextPath();
%>
<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>View Customers</title>
<style>
body{margin:0;background:#f0f4f8;color:#183153;font-family:Arial}
header{background:#102a56;color:white;padding:20px 4%;display:flex;justify-content:space-between;flex-wrap:wrap}
header a{color:white}main{width:95%;margin:25px auto}.panel{background:white;padding:22px;border-radius:12px}
.wrap{overflow-x:auto}table{width:100%;border-collapse:collapse}
td,th{text-align:left;padding:12px;border-bottom:1px solid #ddd;white-space:nowrap}
th{background:#eaf0f6}
</style></head><body>
<header><h2>Registered Customers</h2><a href="<%=ctx%>/admin-dashboard.jsp">Dashboard</a></header>
<main><section class="panel"><h2>Customer List</h2><div class="wrap"><table>
<tr><th>Customer ID</th><th>Full Name</th><th>Username</th><th>Email</th>
<th>Phone</th><th>Registered</th><th>Active</th></tr>
<%if(customers!=null&&!customers.isEmpty()){for(Map<String,Object> c:customers){%>
<tr><td><%=esc(c.get("CUSTOMER_ID"))%></td><td><%=esc(c.get("FULL_NAME"))%></td>
<td><%=esc(c.get("USERNAME"))%></td><td><%=esc(c.get("EMAIL"))%></td>
<td><%=esc(c.get("PHONE"))%></td><td><%=esc(c.get("CREATED_AT"))%></td>
<td><%=esc(c.get("ACTIVE"))%></td></tr>
<%}}else{%><tr><td colspan="7">No customers registered yet.</td></tr><%}%>
</table></div></section></main></body></html>
