
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>

<%
    // Check whether an admin is logged in
    Object adminId = session.getAttribute("adminId");
    Object role = session.getAttribute("role");

    if (adminId == null && !"ADMIN".equals(role)) {
        response.sendRedirect(
            request.getContextPath() + "/admin-login.jsp"
        );
        return;
    }

    String adminName = "Administrator";

    if (session.getAttribute("adminName") != null) {
        adminName = session.getAttribute("adminName").toString();
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard - Hotel Management System</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f3f5f9;
            color: #263238;
        }

        .navbar {
            background: #172b4d;
            color: white;
            padding: 18px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .navbar h2 {
            font-size: 23px;
        }

        .navbar-right {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .welcome {
            font-size: 14px;
        }

        .logout-btn {
            background: #e74c3c;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 6px;
            font-weight: bold;
        }

        .logout-btn:hover {
            background: #c0392b;
        }

        .container {
            max-width: 1150px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .heading {
            margin-bottom: 25px;
        }

        .heading h1 {
            font-size: 29px;
            margin-bottom: 8px;
            color: #172b4d;
        }

        .heading p {
            color: #657080;
        }

        .cards {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(230px, 1fr));
            gap: 22px;
        }

        .card {
            background: white;
            padding: 27px;
            border-radius: 12px;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.07);
            border-top: 4px solid #d4a64a;
            transition: transform 0.2s;
        }

        .card:hover {
            transform: translateY(-4px);
        }

        .card .icon {
            font-size: 34px;
            margin-bottom: 15px;
        }

        .card h3 {
            color: #172b4d;
            margin-bottom: 10px;
            font-size: 20px;
        }

        .card p {
            color: #687385;
            font-size: 14px;
            line-height: 1.6;
            min-height: 45px;
            margin-bottom: 20px;
        }

        .card a {
            display: inline-block;
            background: #172b4d;
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 14px;
        }

        .card a:hover {
            background: #284775;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #7a8492;
            font-size: 13px;
        }

        @media (max-width: 600px) {
            .navbar {
                align-items: flex-start;
            }

            .navbar-right {
                width: 100%;
                justify-content: space-between;
            }
        }
    </style>
</head>

<body>

    <header class="navbar">
        <h2>Hotel Management System</h2>

        <div class="navbar-right">
            <span class="welcome">
                Welcome, <%= adminName %>
            </span>

            <!-- Logout link -->
            <a href="${pageContext.request.contextPath}/logout">Logout</a>
        </div>
    </header>

    <main class="container">

        <section class="heading">
            <h1>Admin Dashboard</h1>
            <p>Manage your hotel's rooms, customers, bookings and billing.</p>
        </section>

        <section class="cards">

            <!-- Manage Rooms -->
            <div class="card">
                <div class="icon">🛏️</div>
                <h3>Manage Rooms</h3>
                <p>Add new rooms, update room details, prices and availability.</p>
                <a href="<%= request.getContextPath() %>/admin-rooms">
                    Manage Rooms
                </a>
            </div>

            <!-- View Customers -->
            <div class="card">
                <div class="icon">👥</div>
                <h3>View Customers</h3>
                <p>View registered customers and their contact information.</p>
                <a href="<%= request.getContextPath() %>/admin-customers">
                    View Customers
                </a>
            </div>

            <!-- Manage Bookings -->
            <div class="card">
                <div class="icon">📅</div>
                <h3>Manage Bookings</h3>
                <p>Review customer reservations, room details and booking status.</p>
                <a href="<%= request.getContextPath() %>/admin-bookings">
                    Manage Bookings
                </a>
            </div>

            <!-- Manage Billing -->
            <div class="card">
                <div class="icon">💳</div>
                <h3>Manage Billing</h3>
                <p>View payment records, amounts paid and outstanding balances.</p>
                <a href="<%= request.getContextPath() %>/admin-billing">
                    Manage Billing
                </a>
            </div>

        </section>
    </main>

    <footer>
        &copy; 2026 Hotel Management System | Admin Panel
    </footer>

</body>
</html>
