
<%@ page import="java.util.List,java.util.Map" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
String esc(Object v) {
    if(v==null)return "";
    return v.toString().replace("&","&amp;").replace("<","&lt;")
        .replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");
}
%>
<%
if(session.getAttribute("adminId")==null &&
   !"ADMIN".equals(session.getAttribute("role"))){
    response.sendRedirect(request.getContextPath()+"/admin-login.jsp");
    return;
}
List<Map<String,Object>> rooms=(List<Map<String,Object>>)request.getAttribute("rooms");
String ctx=request.getContextPath();
%>
<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Rooms</title>
<style>
body{margin:0;font-family:Arial;background:#f0f4f8;color:#183153}
header{background:#102a56;color:white;padding:20px 4%;display:flex;justify-content:space-between;flex-wrap:wrap}
header a{color:white}main{width:94%;margin:25px auto}
.panel{background:white;padding:22px;border-radius:12px;margin-bottom:22px}
.fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
label{display:block;margin:8px 0;font-weight:bold}
input,select,textarea{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:6px;box-sizing:border-box}
button{background:#0e766e;color:white;border:0;border-radius:6px;padding:10px 14px;cursor:pointer}
.del{background:#b91c1c}.wrap{overflow-x:auto}table{width:100%;border-collapse:collapse}
td,th{text-align:left;padding:11px;border-bottom:1px solid #ddd}
th{background:#eaf0f6}.photo{width:90px;height:60px;object-fit:cover;border-radius:6px}
.msg{background:#dcfce7;padding:12px;margin-bottom:15px;border-radius:6px}
@media(max-width:650px){.fields{grid-template-columns:1fr}}
</style></head><body>
<header><h2>Manage Rooms</h2><a href="<%=ctx%>/admin-dashboard.jsp">Dashboard</a></header>
<main>
<%if(request.getParameter("message")!=null){%>
<div class="msg"><%=esc(request.getParameter("message"))%></div><%}%>
<section class="panel">
<h2 id="title">Add Hotel Room</h2>
<form method="post" action="<%=ctx%>/admin-rooms" id="roomForm">
<input type="hidden" name="action" id="action" value="add">
<input type="hidden" name="roomId" id="roomId">
<div class="fields">
<div><label>Room Number *</label><input name="roomNumber" id="roomNumber" required></div>
<div><label>Room Type *</label><select name="roomType" id="roomType">
<option>Standard Room</option><option>Twin Sharing Room</option>
<option>Deluxe Room</option><option>Luxury Suite</option>
<option>Family Room</option><option>Executive Suite</option>
<option>Presidential Suite</option></select></div>
<div><label>Price per Night (₹) *</label><input type="number" name="price" id="price" min="1" step=".01" required></div>
<div><label>Status</label><select name="status" id="status">
<option value="AVAILABLE">AVAILABLE</option>
<option value="UNAVAILABLE">UNAVAILABLE</option></select></div>
<div><label>Photo URL</label><input type="url" name="imageUrl" id="imageUrl"></div>
<div><label>Description</label><textarea name="description" id="description"></textarea></div>
</div><p><button id="save">Add Room</button>
<button type="button" onclick="resetForm()">Clear</button></p>
</form></section>

<section class="panel"><h2>Hotel Rooms</h2><div class="wrap"><table>
<tr><th>Photo</th><th>Room No.</th><th>Type</th><th>Description</th>
<th>Price</th><th>Status</th><th>Actions</th></tr>
<%if(rooms!=null&&!rooms.isEmpty()){for(Map<String,Object> r:rooms){%>
<tr>
<td><%if(r.get("IMAGE_URL")!=null&&!r.get("IMAGE_URL").toString().isEmpty()){%>
<img class="photo" src="<%=esc(r.get("IMAGE_URL"))%>" alt="Room"
onerror="this.style.display='none'"><%}else{%>No photo<%}%></td>
<td><%=esc(r.get("ROOM_NUMBER"))%></td><td><%=esc(r.get("ROOM_TYPE"))%></td>
<td><%=esc(r.get("DESCRIPTION"))%></td>
<td>₹<%=esc(r.get("PRICE_PER_NIGHT"))%></td>
<td><%=esc(r.get("ROOM_STATUS"))%></td>
<td>
<button type="button" onclick="editRoom(this)"
data-id="<%=esc(r.get("ROOM_ID"))%>"
data-number="<%=esc(r.get("ROOM_NUMBER"))%>"
data-type="<%=esc(r.get("ROOM_TYPE"))%>"
data-price="<%=esc(r.get("PRICE_PER_NIGHT"))%>"
data-status="<%=esc(r.get("ROOM_STATUS"))%>"
data-image="<%=esc(r.get("IMAGE_URL"))%>"
data-description="<%=esc(r.get("DESCRIPTION"))%>">Edit</button>
<form method="post" action="<%=ctx%>/admin-rooms" style="display:inline"
onsubmit="return confirm('Delete this room?')">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="roomId" value="<%=esc(r.get("ROOM_ID"))%>">
<button class="del">Delete</button></form>
</td></tr>
<%}}else{%><tr><td colspan="7">No rooms added yet.</td></tr><%}%>
</table></div></section>
</main>
<script>
function editRoom(b){
 const d=b.dataset;
 document.getElementById('title').textContent='Edit Hotel Room';
 document.getElementById('action').value='update';
 document.getElementById('roomId').value=d.id;
 document.getElementById('roomNumber').value=d.number;
 document.getElementById('roomType').value=d.type;
 document.getElementById('price').value=d.price;
 document.getElementById('status').value=d.status;
 document.getElementById('imageUrl').value=d.image;
 document.getElementById('description').value=d.description;
 document.getElementById('save').textContent='Save Changes';
 window.scrollTo(0,0);
}
function resetForm(){
 document.getElementById('roomForm').reset();
 document.getElementById('action').value='add';
 document.getElementById('roomId').value='';
 document.getElementById('title').textContent='Add Hotel Room';
 document.getElementById('save').textContent='Add Room';
}
</script></body></html>
