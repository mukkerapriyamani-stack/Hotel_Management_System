
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    if (session.getAttribute("customerId") == null ||
        !"CUSTOMER".equals(session.getAttribute("role"))) {
        response.sendRedirect(request.getContextPath() + "/customer-login.jsp");
        return;
    }

    Object priceObject = request.getAttribute("price");
    String price = priceObject == null ? "0" : priceObject.toString();

    String imageUrl = (String) request.getAttribute("imageUrl");
    if (imageUrl == null) imageUrl = "";

    String errorMessage = (String) request.getAttribute("errorMessage");
    String safeError = "";
    if (errorMessage != null) {
        safeError = errorMessage.replace("&", "&amp;")
                                .replace("<", "&lt;")
                                .replace(">", "&gt;")
                                .replace("\"", "&quot;");
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Book Your Room</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f0f4f8;
            color: #183153;
        }
        .header {
            background: #102a56;
            color: white;
            padding: 20px 6%;
        }
        .container {
            width: min(1000px, 92%);
            margin: 30px auto;
            display: grid;
            grid-template-columns: 0.9fr 1.1fr;
            gap: 25px;
            align-items: start;
        }
        .room, .form-card {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 8px 24px #172b4d12;
        }
        .room img {
            width: 100%;
            height: 260px;
            object-fit: cover;
            display: block;
        }
        .room-info, .form-card { padding: 25px; }
        h2 { margin-top: 0; }
        .price { color: #087f70; font-size: 24px; font-weight: bold; }
        label {
            display: block;
            font-weight: bold;
            margin: 15px 0 7px;
        }
        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 15px;
        }
        .dates {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        .total {
            margin-top: 20px;
            padding: 16px;
            background: #e5f7f2;
            border-radius: 10px;
        }
        .total strong { color: #087f70; font-size: 23px; }
        button {
            width: 100%;
            margin-top: 20px;
            padding: 15px;
            border: 0;
            border-radius: 9px;
            background: #0e766e;
            color: white;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover { background: #095d57; }
        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 8px;
        }
        .back { color: white; }
        @media (max-width: 700px) {
            .container { grid-template-columns: 1fr; }
            .room img { height: 220px; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Complete Your Booking</h1>
        <a class="back" href="<%= request.getContextPath() %>/customer-rooms">
            &larr; Back to Rooms
        </a>
    </div>

    <main class="container">
        <section class="room">
            <img src="<%= imageUrl.replace("\"", "%22") %>"
                 alt="Selected hotel room">
            <div class="room-info">
                <h2><%= request.getAttribute("roomType") %></h2>
                <p>Room Number: <strong><%= request.getAttribute("roomNumber") %></strong></p>
                <p><%= request.getAttribute("description") %></p>
                <p class="price">₹<%= price %> <small>/ night</small></p>
            </div>
        </section>

        <section class="form-card">
            <h2>Guest and Stay Details</h2>

            <% if (!safeError.isEmpty()) { %>
                <p class="error"><%= safeError %></p>
            <% } %>

            <form method="post"
                  action="<%= request.getContextPath() %>/book-room"
                  id="bookingForm">

                <input type="hidden" name="roomId"
                       value="<%= request.getAttribute("roomId") %>">

                <label for="fullName">Full Name</label>
                <input id="fullName" name="fullName" type="text"
                       maxlength="100" required
                       value="<%= request.getAttribute("fullName") == null ? "" :
                           ((String)request.getAttribute("fullName"))
                           .replace("&", "&amp;").replace("\"", "&quot;")
                           .replace("<", "&lt;").replace(">", "&gt;") %>">

                <label for="email">Email Address</label>
                <input id="email" name="email" type="email"
                       maxlength="150" required
                       value="<%= request.getAttribute("email") == null ? "" :
                           ((String)request.getAttribute("email"))
                           .replace("&", "&amp;").replace("\"", "&quot;")
                           .replace("<", "&lt;").replace(">", "&gt;") %>">

                <label for="phone">Phone Number</label>
                <input id="phone" name="phone" type="tel"
                       maxlength="20" required
                       value="<%= request.getAttribute("phone") == null ? "" :
                           ((String)request.getAttribute("phone"))
                           .replace("&", "&amp;").replace("\"", "&quot;")
                           .replace("<", "&lt;").replace(">", "&gt;") %>">

                <div class="dates">
                    <div>
                        <label for="checkIn">Check-in</label>
                        <input id="checkIn" name="checkIn" type="date" required>
                    </div>
                    <div>
                        <label for="checkOut">Check-out</label>
                        <input id="checkOut" name="checkOut" type="date" required>
                    </div>
                </div>

                <label for="guests">Number of Guests</label>
                <input id="guests" name="guests" type="number"
                       min="1" max="10" value="1" required>

                <div class="total">
                    <div>Number of nights: <strong id="nights">0</strong></div>
                    <div>Estimated total: <strong id="total">₹0.00</strong></div>
                    <small>Final total is calculated again on the server.</small>
                </div>

                <button type="submit">Confirm Booking</button>
            </form>
        </section>
    </main>

    <script>
        const checkIn = document.getElementById("checkIn");
        const checkOut = document.getElementById("checkOut");
        const nightsElement = document.getElementById("nights");
        const totalElement = document.getElementById("total");
        const price = Number("<%= price %>");

        const today = new Date();
        const localToday = new Date(
            today.getTime() - today.getTimezoneOffset() * 60000
        ).toISOString().slice(0, 10);

        checkIn.min = localToday;
        checkOut.min = localToday;

        function calculateTotal() {
            if (checkIn.value) {
                checkOut.min = checkIn.value;
            }

            const start = new Date(checkIn.value + "T00:00:00");
            const end = new Date(checkOut.value + "T00:00:00");

            const nights = Math.round((end - start) / 86400000);

            if (checkIn.value && checkOut.value && nights > 0) {
                nightsElement.textContent = nights;
                totalElement.textContent =
                    "₹" + (nights * price).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    });
            } else {
                nightsElement.textContent = "0";
                totalElement.textContent = "₹0.00";
            }
        }

        checkIn.addEventListener("change", calculateTotal);
        checkOut.addEventListener("change", calculateTotal);

        document.getElementById("bookingForm").addEventListener("submit", function(e) {
            if (!checkIn.value || !checkOut.value ||
                checkOut.value <= checkIn.value) {
                e.preventDefault();
                alert("Please select a valid check-in and check-out date.");
            }
        });
    </script>
</body>
</html>
