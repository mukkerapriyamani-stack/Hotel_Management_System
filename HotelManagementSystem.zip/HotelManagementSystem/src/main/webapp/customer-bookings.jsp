
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%!
    public String safe(Object value) {
        if (value == null) return "";
        return value.toString()
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;");
    }
%>

<%
    if (session.getAttribute("customerId") == null ||
        !"CUSTOMER".equals(session.getAttribute("role"))) {
        response.sendRedirect(request.getContextPath() + "/customer-login.jsp");
        return;
    }

    List<Map<String, Object>> bookings =
        (List<Map<String, Object>>) request.getAttribute("bookings");

    boolean bookingSuccess =
        "true".equals(request.getParameter("bookingSuccess"));
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Bookings | Hotel Management System</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f0f4f8;
            color: #183153;
        }

        header {
            background: #102a56;
            color: white;
            padding: 22px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            font-size: 25px;
            margin: 0;
        }

        header a {
            color: white;
            text-decoration: none;
            margin-left: 12px;
        }

        main {
            width: 92%;
            max-width: 1100px;
            margin: 35px auto;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #86efac;
            border-radius: 12px;
            padding: 18px 20px;
            margin-bottom: 25px;
        }

        .success h2 {
            margin: 0 0 8px;
            font-size: 22px;
        }

        .success p { margin: 0; }

        .booking-card {
            background: white;
            padding: 25px;
            margin-bottom: 22px;
            border-radius: 15px;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.07);
        }

        .booking-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 15px;
            margin-bottom: 18px;
        }

        .booking-top h2 {
            margin: 0;
            color: #102a56;
        }

        .status {
            padding: 8px 13px;
            border-radius: 20px;
            background: #dcfce7;
            color: #166534;
            font-size: 14px;
            font-weight: bold;
        }

        .details {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .detail {
            padding: 12px;
            background: #f8fafc;
            border-radius: 9px;
        }

        .detail span {
            display: block;
            color: #64748b;
            font-size: 14px;
            margin-bottom: 7px;
        }

        .detail strong {
            font-size: 16px;
            overflow-wrap: anywhere;
        }

        .amount {
            color: #087f70;
            font-size: 24px !important;
        }

        .empty {
            background: white;
            padding: 45px 20px;
            text-align: center;
            border-radius: 15px;
        }

        .button {
            display: inline-block;
            margin-top: 22px;
            background: #0e766e;
            color: white;
            text-decoration: none;
            padding: 13px 20px;
            border-radius: 8px;
            font-weight: bold;
        }

        .button:hover { background: #095d57; }

        @media (max-width: 600px) {
            .details { grid-template-columns: 1fr; }
            .booking-card { padding: 18px; }
            header h1 { font-size: 21px; }
        }
    </style>
</head>

<body>

<header>
    <h1>My Bookings</h1>

    <nav>
        <a href="<%= request.getContextPath() %>/customer-portal.jsp">
            Dashboard
        </a>
        <a href="<%= request.getContextPath() %>/customer-rooms">
            View Rooms
        </a>
    </nav>
</header>

<main>

    <% if (bookingSuccess) { %>
        <div class="success">
            <h2>&#10003; Room booked successfully!</h2>
            <p>Your booking has been saved. Here are your booking details.</p>
        </div>
    <% } %>

    <h2>Your Booking History</h2>

    <% if (bookings == null || bookings.isEmpty()) { %>

        <div class="empty">
            <h3>No bookings yet</h3>
            <p>Choose a room and confirm your booking to see it here.</p>

            <a class="button"
               href="<%= request.getContextPath() %>/customer-rooms">
                Browse Rooms
            </a>
        </div>

    <% } else { %>

        <% for (Map<String, Object> b : bookings) { %>

            <section class="booking-card">

                <div class="booking-top">
                    <h2>Booking #<%= safe(b.get("BOOKING_ID")) %></h2>

                    <span class="status">
                        <%= safe(b.get("BOOKING_STATUS")) %>
                    </span>
                </div>

                <div class="details">

                    <div class="detail">
                        <span>Room Type</span>
                        <strong><%= safe(b.get("ROOM_TYPE")) %></strong>
                    </div>

                    <div class="detail">
                        <span>Room Number</span>
                        <strong><%= safe(b.get("ROOM_NUMBER")) %></strong>
                    </div>

                    <div class="detail">
                        <span>Check-in Date</span>
                        <strong><%= safe(b.get("CHECK_IN_DATE")) %></strong>
                    </div>

                    <div class="detail">
                        <span>Check-out Date</span>
                        <strong><%= safe(b.get("CHECK_OUT_DATE")) %></strong>
                    </div>

                    <div class="detail">
                        <span>Number of Guests</span>
                        <strong><%= safe(b.get("NUMBER_OF_GUESTS")) %></strong>
                    </div>

                    <div class="detail">
                        <span>Booking Date</span>
                        <strong><%= safe(b.get("BOOKING_DATE")) %></strong>
                    </div>

                    <div class="detail">
                        <span>Total Amount</span>
                        <strong class="amount">
                            ₹<%= safe(b.get("TOTAL_AMOUNT")) %>
                        </strong>
                    </div>

                </div>

            </section>

        <% } %>

        <a class="button"
           href="<%= request.getContextPath() %>/customer-rooms">
            Book Another Room
        </a>

    <% } %>

</main>

</body>
</html>
