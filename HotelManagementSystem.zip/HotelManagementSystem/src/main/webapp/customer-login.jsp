
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Customer Login</title>
<style>
* { box-sizing: border-box; }
body {
    margin: 0; padding: 20px; min-height: 100vh;
    display: flex; align-items: center; justify-content: center;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #172554, #0f766e);
}
.card {
    background: white; padding: 32px; width: 100%;
    max-width: 430px; border-radius: 14px;
    box-shadow: 0 10px 30px #0003;
}
h1 { color: #172554; text-align: center; }
.subtitle { color: #666; text-align: center; }
label { display: block; margin: 18px 0 7px; font-weight: bold; }
input {
    width: 100%; padding: 12px; border: 1px solid #bbb;
    border-radius: 6px; font-size: 15px;
}
button {
    width: 100%; padding: 13px; margin-top: 22px;
    border: 0; border-radius: 6px; background: #0f766e;
    color: white; font-size: 16px; cursor: pointer;
}
button:hover { background: #115e59; }
.error, .success {
    padding: 12px; margin: 14px 0; border-radius: 6px;
    overflow-wrap: anywhere;
}
.error { background: #fee2e2; color: #991b1b; }
.success { background: #dcfce7; color: #166534; }
.links { text-align: center; margin-top: 20px; line-height: 2; }
a { color: #0f766e; text-decoration: none; }
</style>
</head>
<body>
<div class="card">
    <h1>Customer Login</h1>
    <p class="subtitle">Sign in to your Hotel Customer Portal.</p>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error">
            <%= String.valueOf(request.getAttribute("error"))
                .replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;")
                .replace("'", "&#39;") %>
            <br>
            <a href="${pageContext.request.contextPath}/customer-register.jsp">
                Create an account
            </a>
        </div>
    <% } %>

    <% if ("true".equals(request.getParameter("registered"))) { %>
        <div class="success">
            Account created successfully! Please log in.
        </div>
    <% } %>

    <form action="${pageContext.request.contextPath}/customer-login"
          method="post">

        <label for="username">Username</label>
        <input type="text" id="username" name="username"
               maxlength="50" autocomplete="username" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password"
               autocomplete="current-password" required>

        <button type="submit">Login</button>
    </form>

    <div class="links">
        Don't have an account?
        <a href="${pageContext.request.contextPath}/customer-register.jsp">
            Create Account
        </a>
        <br>
        <a href="${pageContext.request.contextPath}/login.jsp">
            Admin Login
        </a>
        <br>
        <a href="${pageContext.request.contextPath}/index.jsp">Back to Home</a>
    </div>
</div>
</body>
</html>
