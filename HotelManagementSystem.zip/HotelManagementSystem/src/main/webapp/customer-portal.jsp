
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%
    if (session.getAttribute("customerId") == null ||
        !"CUSTOMER".equals(session.getAttribute("role"))) {
        response.sendRedirect(request.getContextPath() + "/customer-login.jsp");
        return;
    }

    String customerName = (String) session.getAttribute("customerName");

    if (customerName == null) {
        customerName = "Customer";
    }

    String safeName = customerName
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&#39;");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Dashboard - Hotel Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f0f4f8;
            color: #183153;
        }

        .welcome {
            background: white;
            margin: 6px;
            padding: 28px 30px;
            border-radius: 16px;
            box-shadow: 0 5px 20px rgba(15, 23, 42, 0.06);
        }

        .welcome h1 {
            color: #087f70;
            margin-top: 0;
            font-size: 30px;
        }

        .welcome p {
            color: #111827;
            font-size: 18px;
            line-height: 1.5;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 300px));
            gap: 24px;
            margin: 30px 6px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(15, 23, 42, 0.06);
        }

        .card h2 {
            color: #102a56;
            font-size: 23px;
            margin-top: 20px;
        }

        .card p {
            color: #111827;
            font-size: 18px;
            line-height: 1.4;
            min-height: 50px;
        }

        .button {
            display: inline-block;
            margin-top: 12px;
            padding: 13px 18px;
            background: #0e766e;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 17px;
        }

        .button:hover {
            background: #095d57;
        }

        footer {
            text-align: center;
            color: #64748b;
            padding: 30px 15px;
            font-size: 18px;
        }

        @media (max-width: 680px) {
            .cards {
                grid-template-columns: 1fr;
                margin: 20px 10px;
            }

            .welcome {
                padding: 22px;
            }

            .welcome h1 {
                font-size: 25px;
            }
        }
    </style>
</head>

<body>

    <section class="welcome">
        <h1>Welcome, <%= safeName %>!</h1>

        <p>Your account is logged in successfully.</p>

        <p>Choose an option below to manage your hotel stay.</p>
    </section>

    <main class="cards">

        <!-- Available Rooms -->
        <section class="card">
            <h2>Available Rooms</h2>

            <p>View available rooms, photos, and prices.</p>

            <a class="button"
               href="<%= request.getContextPath() %>/customer-rooms">
                View Rooms
            </a>
        </section>

        <!-- Booking History -->
        <section class="card">
            <h2>Booking History</h2>

            <p>View your current and previous bookings.</p>

            <a class="button"
               href="<%= request.getContextPath() %>/customer-bookings">
                My Bookings
            </a>
        </section>

    </main>

    <footer>
        Hotel Management System
    </footer>

</body>
</html>
