
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create Customer Account</title>
<style>
* { box-sizing: border-box; }
body {
    margin: 0; padding: 20px; min-height: 100vh;
    display: flex; align-items: center; justify-content: center;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #172554, #0f766e);
}
.card {
    background: white; padding: 30px; width: 100%;
    max-width: 470px; border-radius: 14px;
    box-shadow: 0 10px 30px #0003;
}
h1 { text-align: center; color: #172554; }
.subtitle { text-align: center; color: #666; }
label { display: block; margin: 14px 0 6px; font-weight: bold; }
input {
    width: 100%; padding: 11px; border: 1px solid #bbb;
    border-radius: 6px; font-size: 15px;
}
button {
    width: 100%; margin-top: 22px; padding: 13px;
    background: #0f766e; color: white; border: 0;
    border-radius: 6px; font-size: 16px; cursor: pointer;
}
button:hover { background: #115e59; }
.error, .success {
    padding: 12px; margin: 14px 0; border-radius: 6px;
    overflow-wrap: anywhere;
}
.error { background: #fee2e2; color: #991b1b; }
.success { background: #dcfce7; color: #166534; }
.links { text-align: center; margin-top: 20px; line-height: 2; }
a { color: #0f766e; text-decoration: none; }
</style>
</head>
<body>
<div class="card">
    <h1>Create Account</h1>
    <p class="subtitle">Register to book your hotel room.</p>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error">
            <%= String.valueOf(request.getAttribute("error"))
                .replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;")
                .replace("'", "&#39;") %>
        </div>
    <% } %>

    <form action="${pageContext.request.contextPath}/customer-register"
          method="post">

        <label for="fullName">Full Name</label>
        <input type="text" id="fullName" name="fullName"
               maxlength="100" required>

        <label for="username">Username</label>
        <input type="text" id="username" name="username"
               maxlength="50" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email"
               maxlength="150" required>

        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone"
               maxlength="20" required>

        <label for="password">Password (at least 8 characters)</label>
        <input type="password" id="password" name="password"
               minlength="8" autocomplete="new-password" required>

        <label for="confirmPassword">Confirm Password</label>
        <input type="password" id="confirmPassword"
               name="confirmPassword" minlength="8"
               autocomplete="new-password" required>

        <button type="submit">Create Account</button>
    </form>

    <div class="links">
        Already have an account?
        <a href="${pageContext.request.contextPath}/customer-login.jsp">
            Login here
        </a>
        <br>
        <a href="${pageContext.request.contextPath}/index.jsp">Back to Home</a>
    </div>
</div>
</body>
</html>
