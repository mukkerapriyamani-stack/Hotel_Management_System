
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%
    if (session.getAttribute("customerId") == null ||
        !"CUSTOMER".equals(session.getAttribute("role"))) {
        response.sendRedirect(request.getContextPath() + "/customer-login.jsp");
        return;
    }

    List<Map<String, Object>> rooms =
        (List<Map<String, Object>>) request.getAttribute("rooms");

    String contextPath = request.getContextPath();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Available Rooms | Hotel Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f0f4f8;
            color: #183153;
        }

        .header {
            background: #102a56;
            color: white;
            padding: 22px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .header h1 {
            margin: 0;
            font-size: 27px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            width: 96%;
            max-width: 1500px;
            margin: 30px auto;
        }

        .page-title {
            text-align: center;
            margin-bottom: 30px;
        }

        .page-title h2 {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .page-title p {
            color: #64748b;
            font-size: 17px;
        }

        .room-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 30px;
        }

        .room-card {
            background: white;
            border-radius: 17px;
            overflow: hidden;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
            display: flex;
            flex-direction: column;
            transition: transform 0.2s ease;
        }

        .room-card:hover {
            transform: translateY(-4px);
        }

        .room-image {
            width: 100%;
            height: 220px;
            object-fit: cover;
            display: block;
            background: #e2e8f0;
        }

        .room-info {
            padding: 25px;
            display: flex;
            flex-direction: column;
            flex: 1;
        }

        .room-info h3 {
            font-size: 25px;
            color: #102a56;
            margin: 0 0 18px;
        }

        .description {
            font-size: 17px;
            line-height: 1.7;
            color: #64748b;
            margin: 0 0 18px;
        }

        .room-number {
            color: #64748b;
            margin: 0 0 20px;
        }

        .price {
            font-size: 29px;
            font-weight: bold;
            color: #087f70;
            margin-bottom: 18px;
        }

        .price small {
            font-size: 15px;
            font-weight: normal;
            color: #64748b;
        }

        .status {
            display: inline-block;
            width: fit-content;
            padding: 9px 14px;
            border-radius: 25px;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .available {
            background: #dcfce7;
            color: #166534;
        }

        .unavailable {
            background: #fee2e2;
            color: #991b1b;
        }

        .book-button {
            display: block;
            width: 100%;
            margin-top: auto;
            padding: 15px;
            border-radius: 9px;
            text-align: center;
            text-decoration: none;
            font-size: 17px;
            font-weight: bold;
            background: #0e766e;
            color: white;
            border: none;
        }

        .book-button:hover {
            background: #095d57;
        }

        .disabled-button {
            background: #94a3b8;
            cursor: not-allowed;
        }

        .empty-message {
            background: white;
            text-align: center;
            padding: 45px 20px;
            border-radius: 15px;
            color: #64748b;
            font-size: 18px;
        }

        .footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
        }

        @media (max-width: 1050px) {
            .room-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 22px;
            }
        }

        @media (max-width: 650px) {
            .room-grid {
                grid-template-columns: 1fr;
            }

            .header h1 {
                font-size: 22px;
            }

            .page-title h2 {
                font-size: 26px;
            }

            .room-image {
                height: 230px;
            }

            .room-info {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

<header class="header">
    <h1>Hotel Management System</h1>

    <nav>
        <a href="<%= contextPath %>/customer-portal.jsp">
            Customer Dashboard
        </a>
        &nbsp; | &nbsp;
        <a href="<%= contextPath %>/customer-logout">
            Logout
        </a>
    </nav>
</header>

<main class="container">

    <div class="page-title">
        <h2>Our Available Rooms</h2>
        <p>Choose your room and book your comfortable stay.</p>
    </div>

    <% if (rooms == null || rooms.isEmpty()) { %>

        <div class="empty-message">
            <h3>No rooms have been added yet.</h3>
            <p>Please check again later.</p>
        </div>

    <% } else { %>

        <div class="room-grid">

            <% for (Map<String, Object> room : rooms) {

                Object roomId = room.get("ROOM_ID");
                Object roomNumber = room.get("ROOM_NUMBER");
                Object roomType = room.get("ROOM_TYPE");
                Object description = room.get("DESCRIPTION");
                Object roomPrice = room.get("PRICE_PER_NIGHT");
                Object roomStatus = room.get("ROOM_STATUS");
                Object imageUrl = room.get("IMAGE_URL");

                String typeText = roomType == null
                    ? "Hotel Room" : roomType.toString();

                String descriptionText = description == null
                    ? "Enjoy a comfortable stay with our room amenities."
                    : description.toString();

                String numberText = roomNumber == null
                    ? "" : roomNumber.toString();

                String priceText = roomPrice == null
                    ? "0.00" : roomPrice.toString();

                String statusText = roomStatus == null
                    ? "Unavailable" : roomStatus.toString();

                boolean isAvailable =
                    "AVAILABLE".equalsIgnoreCase(statusText);

                String imageText = imageUrl == null
                    ? "" : imageUrl.toString();

                String safeType = typeText.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;");

                String safeDescription = descriptionText
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;");

                String safeNumber = numberText
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;");

                String safePrice = priceText
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;");

                String safeImage = imageText
                    .replace("&", "&amp;")
                    .replace("\"", "&quot;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;");

            %>

            <article class="room-card">

                <% if (!imageText.trim().isEmpty()) { %>
                    <img
                        class="room-image"
                        src="<%= safeImage %>"
                        alt="<%= safeType %>"
                        loading="lazy"
                        onerror="this.style.display='none';">
                <% } else { %>
                    <div class="room-image"></div>
                <% } %>

                <div class="room-info">

                    <h3><%= safeType %></h3>

                    <p class="description">
                        <%= safeDescription %>
                    </p>

                    <p class="room-number">
                        Room Number: <%= safeNumber %>
                    </p>

                    <div class="price">
                        ₹<%= safePrice %>
                        <small>/ night</small>
                    </div>

                    <span class="status <%= isAvailable
                        ? "available" : "unavailable" %>">
                        <%= isAvailable ? "Available" : "Unavailable" %>
                    </span>

                    <% if (isAvailable && roomId != null) { %>

                        <a class="book-button"
                           href="<%= contextPath %>/book-room?roomId=<%= roomId %>">
                            Book This Room
                        </a>

                    <% } else { %>

                        <span class="book-button disabled-button">
                            Currently Unavailable
                        </span>

                    <% } %>

                </div>
            </article>

            <% } %>

        </div>

    <% } %>

</main>

<footer class="footer">
    Hotel Management System &copy; 2026
</footer>

</body>
</html>
