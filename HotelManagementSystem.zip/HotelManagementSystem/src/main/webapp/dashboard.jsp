
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>
<%@ page import="java.util.Map" %>

<%
    // Check that an administrator is logged in
    if (session == null ||
        !"ADMIN".equals(session.getAttribute("role"))) {

        response.sendRedirect(
            request.getContextPath() + "/login.jsp");
        return;
    }

    // Read live counts loaded by DashboardServlet
    Map<String, Integer> counts =
        (Map<String, Integer>) request.getAttribute("counts");

    // Direct access to this JSP should load the dashboard
    // through the servlet, which retrieves fresh database data.
    if (counts == null) {
        response.sendRedirect(
            request.getContextPath() + "/dashboard");
        return;
    }

    String adminUsername =
        (String) session.getAttribute("adminUsername");

    if (adminUsername == null) {
        adminUsername = "Admin";
    }

    String contextPath = request.getContextPath();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | GrandStay</title>

    <link rel="stylesheet"
          href="<%= contextPath %>/css/dashboard.css">

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f3f6f7;
            color: #173641;
        }

        .topbar {
            min-height: 72px;
            padding: 16px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            background: #102e3a;
            color: white;
        }

        .brand {
            color: #f0c078;
            font-size: 25px;
            font-weight: bold;
            text-decoration: none;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .welcome {
            font-size: 14px;
        }

        .logout {
            display: inline-block;
            background: #dba75c;
            color: #102e3a;
            padding: 10px 17px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .hero {
            min-height: 270px;
            display: flex;
            align-items: center;
            padding: 45px 6%;
            color: white;
            background:
                linear-gradient(
                    rgba(8, 28, 37, 0.72),
                    rgba(8, 28, 37, 0.72)
                ),
                url("https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1800&q=85")
                center/cover no-repeat;
        }

        .hero h1 {
            font-size: clamp(28px, 4vw, 44px);
            margin-bottom: 12px;
        }

        .hero p {
            line-height: 1.7;
            max-width: 650px;
            color: #f1f4f5;
        }

        .dashboard-main {
            width: min(1400px, 92%);
            margin: 35px auto;
        }

        .section-title {
            font-size: 25px;
            margin-bottom: 8px;
        }

        .section-description {
            color: #6b7b80;
            margin-bottom: 24px;
            line-height: 1.6;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            padding: 24px;
            border: 1px solid #e0e7e9;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(16, 46, 58, 0.05);
            min-width: 0;
        }

        .stat-card h3 {
            color: #65777e;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .stat-card p {
            color: #173641;
            font-size: 34px;
            font-weight: 800;
            overflow-wrap: anywhere;
        }

        .stat-note {
            color: #7a898d;
            font-size: 12px;
            margin-top: 10px;
        }

        .management-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 22px;
            margin-top: 22px;
        }

        .management-card {
            background: white;
            padding: 28px;
            border: 1px solid #e0e7e9;
            border-radius: 12px;
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-height: 230px;
        }

        .management-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(16, 46, 58, 0.09);
        }

        .card-icon {
            font-size: 35px;
            margin-bottom: 20px;
        }

        .management-card h3 {
            font-size: 23px;
            margin-bottom: 12px;
        }

        .management-card p {
            color: #65777e;
            line-height: 1.7;
            margin-bottom: 22px;
        }

        .card-link {
            color: #a96b20;
            text-decoration: none;
            font-weight: bold;
            margin-top: auto;
        }

        .card-link:hover {
            text-decoration: underline;
        }

        .footer {
            text-align: center;
            padding: 28px 15px;
            color: #718087;
            font-size: 13px;
        }

        @media (max-width: 1000px) {
            .stats-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 650px) {
            .topbar {
                align-items: flex-start;
            }

            .topbar-right {
                width: 100%;
                justify-content: space-between;
            }

            .hero {
                min-height: 230px;
                padding: 32px 5%;
            }

            .dashboard-main {
                width: 92%;
                margin: 26px auto;
            }

            .management-grid {
                grid-template-columns: 1fr;
            }

            .management-card {
                padding: 23px;
                min-height: 210px;
            }

            .stat-card {
                padding: 17px;
            }

            .stat-card p {
                font-size: 28px;
            }
        }

        @media (max-width: 380px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .brand {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>

    <header class="topbar">

        <a class="brand"
           href="<%= contextPath %>/dashboard">
            GrandStay.
        </a>

        <div class="topbar-right">
            <span class="welcome">
                Welcome, <%= adminUsername %>
            </span>

            <a class="logout"
               href="<%= contextPath %>/logout">
                Logout
            </a>
        </div>

    </header>

    <section class="hero">
        <div>
            <h1>Hotel Administration</h1>
            <p>
                Manage rooms, reservations, guests and billing
                from one place. Dashboard statistics are retrieved
                from your Oracle database.
            </p>
        </div>
    </section>

    <main class="dashboard-main">

        <h2 class="section-title">Dashboard Overview</h2>

        <p class="section-description">
            Live counts from your hotel database.
        </p>

        <section class="stats-grid">

            <article class="stat-card">
                <h3>Total Rooms</h3>
                <p><%= counts.get("totalRooms") %></p>
                <div class="stat-note">Registered hotel rooms</div>
            </article>

            <article class="stat-card">
                <h3>Available Rooms Today</h3>
                <p><%= counts.get("availableRooms") %></p>
                <div class="stat-note">Available for today's occupancy</div>
            </article>

            <article class="stat-card">
                <h3>Booked Rooms Today</h3>
                <p><%= counts.get("bookedRooms") %></p>
                <div class="stat-note">Rooms with active reservations</div>
            </article>

            <article class="stat-card">
                <h3>Total Bookings</h3>
                <p><%= counts.get("totalBookings") %></p>
                <div class="stat-note">Non-cancelled reservations</div>
            </article>

            <article class="stat-card">
                <h3>Registered Customers</h3>
                <p><%= counts.get("registeredCustomers") %></p>
                <div class="stat-note">Active customer accounts</div>
            </article>

            <article class="stat-card">
                <h3>Paid Bills</h3>
                <p><%= counts.get("paidBills") %></p>
                <div class="stat-note">Fully paid payment records</div>
            </article>

            <article class="stat-card">
                <h3>Unpaid Bills</h3>
                <p><%= counts.get("unpaidBills") %></p>
                <div class="stat-note">Outstanding payment records</div>
            </article>

            <article class="stat-card">
                <h3>Partially Paid Bills</h3>
                <p><%= counts.get("partialBills") %></p>
                <div class="stat-note">Payments awaiting balance</div>
            </article>

        </section>

        <h2 class="section-title">Hotel Management</h2>

        <p class="section-description">
            Select a module to manage your hotel operations.
        </p>

        <section class="management-grid">

            <article class="management-card">
                <div class="card-icon">🏨</div>
                <h3>Room Management</h3>
                <p>
                    Add rooms, edit room types and prices,
                    and manage room availability.
                </p>
                <a class="card-link"
                   href="<%= contextPath %>/rooms">
                    Manage rooms →
                </a>
            </article>

            <article class="management-card">
                <div class="card-icon">📅</div>
                <h3>Booking Management</h3>
                <p>
                    View reservations, customer bookings,
                    and check-in and check-out dates.
                </p>
                <a class="card-link"
                   href="<%= contextPath %>/bookings">
                    Manage bookings →
                </a>
            </article>

            <article class="management-card">
                <div class="card-icon">👥</div>
                <h3>Guest Management</h3>
                <p>
                    View registered customer details,
                    phone numbers and booking information.
                </p>
                <a class="card-link"
                   href="<%= contextPath %>/customers">
                    View customers →
                </a>
            </article>

            <article class="management-card">
                <div class="card-icon">💳</div>
                <h3>Billing</h3>
                <p>
                    Review actual payment records,
                    outstanding balances and paid bills.
                </p>
                <a class="card-link"
                   href="<%= contextPath %>/billing">
                    Manage billing →
                </a>
            </article>

        </section>

    </main>

    <footer class="footer">
        GrandStay Hotel Management System
    </footer>

</body>
</html>
