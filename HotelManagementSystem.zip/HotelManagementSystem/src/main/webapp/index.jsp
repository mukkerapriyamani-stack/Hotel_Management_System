
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hotel Management System</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    font-family: Arial, sans-serif;
    background:
        linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)),
        url('https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1600&q=80')
        center/cover no-repeat fixed;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.container {
    width: 100%;
    max-width: 650px;
    background: rgba(255,255,255,0.96);
    padding: 40px 30px;
    border-radius: 16px;
    text-align: center;
    box-shadow: 0 10px 35px rgba(0,0,0,0.3);
}

h1 {
    color: #203654;
    margin-bottom: 12px;
}

.description {
    color: #555;
    line-height: 1.6;
    margin-bottom: 30px;
}

.login-options {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 14px;
}

.login-btn {
    display: inline-block;
    padding: 14px 20px;
    min-width: 170px;
    background: #203654;
    color: white;
    text-decoration: none;
    border-radius: 7px;
    font-weight: bold;
    transition: background 0.2s;
}

.login-btn:hover {
    background: #426a9c;
}

.customer {
    background: #167d70;
}

.customer:hover {
    background: #106257;
}

.register {
    background: #b7791f;
}

.register:hover {
    background: #8f5b16;
}

footer {
    margin-top: 28px;
    color: #666;
    font-size: 13px;
}

@media (max-width: 480px) {
    .container {
        padding: 28px 18px;
    }

    .login-options {
        flex-direction: column;
    }

    .login-btn {
        width: 100%;
    }
}
</style>
</head>

<body>
<div class="container">

    <h1>Welcome to Our Hotel</h1>

    <p class="description">
        Hotel Management System<br>
        Discover our rooms, check prices and book your stay.
    </p>

    <div class="login-options">

        <a class="login-btn customer"
           href="${pageContext.request.contextPath}/customer-login.jsp">
            Customer Login
        </a>

        <a class="login-btn register"
           href="${pageContext.request.contextPath}/customer-register.jsp">
            Customer Registration
        </a>

        <a class="login-btn"
           href="${pageContext.request.contextPath}/login.jsp">
            Admin Login
        </a>

    </div>

    <footer>
        Comfortable rooms. Easy booking. Better stays.
    </footer>

</div>
</body>
</html>
