
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | GrandStay Hotel</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/login.css">
</head>
<body>

    <main class="login-page">

        <a href="index.jsp" class="back-home">
            &larr; Back to Home
        </a>

        <section class="login-card">
            <a href="index.jsp" class="brand">
                GrandStay<span>.</span>
            </a>

            <p class="eyebrow">HOTEL MANAGEMENT SYSTEM</p>
            <h1>Welcome Back</h1>
            <p class="subtitle">
                Sign in to manage your hotel.
            </p>

            <% if ("1".equals(request.getParameter("error"))) { %>
                <p class="error-message">
                    Invalid username or password. Please try again.
                </p>
            <% } %>

            <% if ("1".equals(request.getParameter("logout"))) { %>
                <p class="success-message">
                    You have been logged out successfully.
                </p>
            <% } %>

            <form action="${pageContext.request.contextPath}/login"
                  method="post">

                <label for="username">Username</label>
                <input type="text"
                       id="username"
                       name="username"
                       placeholder="Enter your username"
                       autocomplete="username"
                       required>

                <label for="password">Password</label>
                <input type="password"
                       id="password"
                       name="password"
                       placeholder="Enter your password"
                       autocomplete="current-password"
                       required>

                <button type="submit">Sign In</button>
            </form>

            <p class="login-footer">
                Authorized hotel administrators only.
            </p>
        </section>

    </main>

</body>
</html>
